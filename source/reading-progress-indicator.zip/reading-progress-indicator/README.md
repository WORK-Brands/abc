Reading Progress Indicator
=========

A widget containing a list of suggested articles, with a reading progress indicator powered by SVG, CSS and jQuery.

[Article on CodyHouse](http://codyhouse.co/gem/reading-progress-indicator/)

[Demo](http://codyhouse.co/demo/reading-progress-indicator/index.html)
 
[Terms](http://codyhouse.co/terms/)
