3D Portfolio Template
=========

A portfolio template, with a filter that triggers 3D rotating sections.

[Article on CodyHouse](http://codyhouse.co/gem/3d-portfolio-template/)

[Demo](http://codyhouse.co/demo/3d-portfolio-template/index.html)
 
[Terms](http://codyhouse.co/terms/)

Images: [Unsplash](https://unsplash.com/)
