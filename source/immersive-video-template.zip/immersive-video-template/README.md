Immersive Video Template

=========

A full-screen video presentation, that is resized and animated to become the content of a mobile device.  

[Article on CodyHouse](https://codyhouse.co/gem/immersive-video-template/)

[Demo](http://codyhouse.co/demo/immersive-video-template/index.html)

Video footage: [pexels.com](https://www.pexels.com/)

Icons: [Nucleo](https://nucleoapp.com/)
 
[Terms](https://codyhouse.co/terms/)
