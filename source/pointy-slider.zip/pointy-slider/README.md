Pointy Slider
=========

A slideshow with sliding-in panels that unveil new, fixed background images.

[Article on CodyHouse](http://codyhouse.co/gem/pointy-slider/)

[Demo](https://codyhouse.co/demo/pointy-slider/index.html)

Inspiration: [shft.run](http://shft.run/)

Images: [Unsplash](https://unsplash.com/)
 
[Terms](http://codyhouse.co/terms/)
